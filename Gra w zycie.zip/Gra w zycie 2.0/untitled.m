function varargout = untitled(varargin)
% UNTITLED MATLAB code for untitled.fig
%      UNTITLED, by itself, creates a new UNTITLED or raises the existing
%      singleton*.
%
%      H = UNTITLED returns the handle to a new UNTITLED or the handle to
%      the existing singleton*.
%
%      UNTITLED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UNTITLED.M with the given input arguments.
%
%      UNTITLED('Property','Value',...) creates a new UNTITLED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before untitled_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to untitled_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help untitled

% Last Modified by GUIDE v2.5 15-May-2019 22:56:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @untitled_OpeningFcn, ...
                   'gui_OutputFcn',  @untitled_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before untitled is made visible.
function untitled_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to untitled (see VARARGIN)

% Choose default command line output for untitled
handles.output = hObject;

handles.len = str2double(get(handles.wsX, 'String'));
handles.GRID=zeros(handles.len,handles.len);
colormap([0 1 1; 1 1 0])
cla
pcolor(handles.GRID);
axis ij
axis off
axis image

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes untitled wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = untitled_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


len=handles.len;
GRID=handles.GRID;
colormap([1 1 0; 0 0 1])

up=[2:len 1]; down=[len 1:len-1]; %the world is round

epoki = str2double(get(handles.edit1, 'String'));

for i=1: epoki
    
    neighbours=GRID(up,:)+GRID(down,:)+GRID(:,up)+GRID(:,down)+GRID(up,up)+GRID(up,down)+GRID(down,up)+GRID(down,down);
    GRID = neighbours==3 | GRID & neighbours==2;

    if ~any(GRID(:))
        
        colormap([1 1 0])
        cla
        pcolor(GRID);
        axis ij
        axis image
        axis off 
        break
        
    end 

    cla
    pcolor(GRID);
    axis ij
    axis image
    axis off 
    pause(0.2);

end

handles.GRID = GRID;
handles.len = str2double(get(handles.wsX, 'String'));
guidata(hObject, handles);


% --- Executes on button press in losowe.
function losowe_Callback(hObject, eventdata, handles)
% hObject    handle to losowe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.GRID(:)=0;
handles.GRID=int8(rand(handles.len,handles.len));
colormap([1 1 0; 0 0 1])

cla
pcolor(handles.GRID);
axis ij
axis off
axis image

guidata(hObject, handles);


% --- Executes on button press in oscylator.
function oscylator_Callback(hObject, eventdata, handles)
% hObject    handle to oscylator (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.GRID(:)=0;
handles.GRID(5,4:6)=1;
colormap([1 1 0; 0 0 1])

cla
pcolor(handles.GRID);
axis ij
axis off
axis image

guidata(hObject, handles);




% --- Executes on button press in niezmienne.
function niezmienne_Callback(hObject, eventdata, handles)
% hObject    handle to niezmienne (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.GRID(:)=0;
handles.GRID(5,5:6)=1;
handles.GRID(4,4)=1;
handles.GRID(4,7)=1;
handles.GRID(3,5:6)=1;

colormap([1 1 0; 0 0 1])
cla
pcolor(handles.GRID);
axis ij
axis off
axis image
guidata(hObject, handles);


% --- Executes on button press in reczne.
function reczne_Callback(hObject, eventdata, handles)
% hObject    handle to reczne (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject, handles);

n=100;

for i=1:n

    [x1, y1]=ginput(1);
    if x1 > handles.len
        break
    end

    handles.GRID(floor(y1),floor(x1))=1;
    colormap([1 1 0; 0 0 1])
    cla
    pcolor(handles.GRID);
    axis ij
    axis off
    axis image

end

guidata(hObject, handles);


% --- Executes on button press in glider.
function glider_Callback(hObject, eventdata, handles)
% hObject    handle to glider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.GRID(:)=0;
handles.GRID(3,1:3)=1;
handles.GRID(2,3)=1;
handles.GRID(1,2)=1;

colormap([1 1 0; 0 0 1])
cla
pcolor(handles.GRID);
axis ij
axis off
axis image

guidata(hObject, handles);

function wsX_Callback(hObject, eventdata, handles)
% hObject    handle to wsX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wsX as text
%        str2double(get(hObject,'String')) returns contents of wsX as a double


% --- Executes during object creation, after setting all properties.
function wsX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wsX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function wsY_Callback(hObject, eventdata, handles)
% hObject    handle to wsY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wsY as text
%        str2double(get(hObject,'String')) returns contents of wsY as a double


% --- Executes during object creation, after setting all properties.
function wsY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wsY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
handles.len = str2double(get(handles.wsX, 'String'));

handles.GRID=zeros(handles.len,handles.len);

colormap([1 1 0; 0 0 1])
cla
pcolor(handles.GRID);
axis ij
axis off
axis image


guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
